const { neon } = require("@neondatabase/serverless");
const sql = neon(process.env.DATABASE_URL);
let ready = null;
const init = () => ready || (ready = sql`CREATE TABLE IF NOT EXISTS users (
  username TEXT PRIMARY KEY, name TEXT NOT NULL, salt TEXT NOT NULL, hash TEXT NOT NULL, created_at BIGINT NOT NULL)`);

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "method" });
  try {
    await init();
    const b = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const username = String(b.username || "").trim().toLowerCase();
    if (!/^[a-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: "bad_username" });

    if (b.action === "register") {
      const name = String(b.name || "").trim().slice(0, 40);
      const salt = String(b.salt || ""), hash = String(b.hash || "");
      if (!name || !salt || !hash) return res.status(400).json({ error: "bad_input" });
      const created = Number(b.created) || Date.now();
      const r = await sql`INSERT INTO users (username,name,salt,hash,created_at)
        VALUES (${username},${name},${salt},${hash},${created})
        ON CONFLICT (username) DO NOTHING RETURNING username`;
      if (!r.length) return res.status(409).json({ error: "taken" });
      return res.json({ ok: true });
    }
    if (b.action === "salt") {
      const r = await sql`SELECT salt FROM users WHERE username=${username}`;
      if (!r.length) return res.status(401).json({ error: "not_found" });
      return res.json({ ok: true, salt: r[0].salt });
    }
    if (b.action === "login") {
      const r = await sql`SELECT name, created_at FROM users WHERE username=${username} AND hash=${String(b.hash || "")}`;
      if (!r.length) return res.status(401).json({ error: "wrong" });
      return res.json({ ok: true, user: { name: r[0].name, created: Number(r[0].created_at) } });
    }
    return res.status(400).json({ error: "action" });
  } catch (e) {
    return res.status(500).json({ error: "server" });
  }
};
