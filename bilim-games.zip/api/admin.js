const { neon } = require("@neondatabase/serverless");
const sql = neon(process.env.DATABASE_URL);

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "method" });
  try {
    const b = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    if (!process.env.ADMIN_PASSWORD || b.password !== process.env.ADMIN_PASSWORD)
      return res.status(401).json({ error: "wrong_password" });
    const users = await sql`SELECT username, name, created_at FROM users ORDER BY created_at DESC`;
    return res.json({ count: users.length, users: users.map(u => ({ ...u, created_at: Number(u.created_at) })) });
  } catch (e) {
    return res.status(500).json({ error: "server" });
  }
};
